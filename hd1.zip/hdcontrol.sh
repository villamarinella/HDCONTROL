#!/bin/bash

echo "Meldung angekommen, also lass uns was tun"
echo $1
## in $1 steht der Prozentwert

exit 0
